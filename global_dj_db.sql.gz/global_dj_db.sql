-- Adminer 3.3.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `AuthAssignment_item_name_fk` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE `auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `AuthItem_rule_name_fk` (`rule_name`),
  KEY `AuthItem_type_idx` (`type`),
  CONSTRAINT `AuthItem_rule_name_fk` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE `auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `AuthItemChild_child_fk` (`child`),
  CONSTRAINT `AuthItemChild_child_fk` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AuthItemChild_parent_fk` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE `auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `core_langs`;
CREATE TABLE `core_langs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(3) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `core_langs` (`id`, `code`, `name`) VALUES
(1,	'ru',	'Russian'),
(2,	'en',	'English');

DROP TABLE IF EXISTS `migration`;
CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base',	1401823468),
('m000000_000001_CreateRbacTables',	1401823470),
('m000000_000002_CreateUserTables',	1401823699);

DROP TABLE IF EXISTS `page_banners`;
CREATE TABLE `page_banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned NOT NULL,
  `picture` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_page_banners_page_pages1` (`page_id`),
  CONSTRAINT `fk_page_banners_page_pages1` FOREIGN KEY (`page_id`) REFERENCES `page_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `page_banners_t`;
CREATE TABLE `page_banners_t` (
  `banners_id` int(10) unsigned NOT NULL,
  `langs_id` int(10) unsigned NOT NULL,
  `title1` text,
  `title2` text,
  PRIMARY KEY (`banners_id`),
  KEY `fk_page_banners_t_core_langs1` (`langs_id`),
  CONSTRAINT `fk_page_banners_t_core_langs1` FOREIGN KEY (`langs_id`) REFERENCES `core_langs` (`id`),
  CONSTRAINT `fk_page_banners_t_page_banners1` FOREIGN KEY (`banners_id`) REFERENCES `page_banners` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `page_content_blocks`;
CREATE TABLE `page_content_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned NOT NULL,
  `background_pic` varchar(255) DEFAULT NULL,
  `background_color` varchar(45) DEFAULT NULL,
  `position` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_page_content_blocks_page_pages1` (`page_id`),
  CONSTRAINT `fk_page_content_blocks_page_pages1` FOREIGN KEY (`page_id`) REFERENCES `page_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `page_content_blocks_t`;
CREATE TABLE `page_content_blocks_t` (
  `content_blocks_id` int(10) unsigned NOT NULL,
  `langs_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text,
  PRIMARY KEY (`content_blocks_id`),
  KEY `fk_page_content_blocks_t_core_langs1` (`langs_id`),
  CONSTRAINT `fk_page_content_blocks_t_core_langs1` FOREIGN KEY (`langs_id`) REFERENCES `core_langs` (`id`),
  CONSTRAINT `fk_page_content_blocks_t_page_content_blocks1` FOREIGN KEY (`content_blocks_id`) REFERENCES `page_content_blocks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `page_main_menu`;
CREATE TABLE `page_main_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `url` varchar(50) NOT NULL,
  `position` int(10) unsigned DEFAULT '0',
  `is_main_page` tinyint(1) DEFAULT '0',
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_page_main_menu_page_pages1` (`page_id`),
  CONSTRAINT `fk_page_main_menu_page_pages1` FOREIGN KEY (`page_id`) REFERENCES `page_pages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `page_main_menu_t`;
CREATE TABLE `page_main_menu_t` (
  `main_menu_id` int(10) unsigned NOT NULL,
  `langs_id` int(10) unsigned NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`main_menu_id`),
  KEY `fk_page_main_menu_t_page_main_menu1` (`main_menu_id`),
  KEY `fk_page_main_menu_t_core_langs1` (`langs_id`),
  CONSTRAINT `fk_page_main_menu_t_core_langs1` FOREIGN KEY (`langs_id`) REFERENCES `core_langs` (`id`),
  CONSTRAINT `fk_page_main_menu_t_page_main_menu1` FOREIGN KEY (`main_menu_id`) REFERENCES `page_main_menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `page_pages`;
CREATE TABLE `page_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `page_pages` (`id`, `url`) VALUES
(1,	'test'),
(2,	'new-one'),
(3,	'hello'),
(10,	'tre'),
(11,	'treee');

DROP TABLE IF EXISTS `page_pages_t`;
CREATE TABLE `page_pages_t` (
  `page_id` int(10) unsigned NOT NULL,
  `langs_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(500) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`page_id`),
  KEY `fk_page_pages_t_core_langs1` (`langs_id`),
  CONSTRAINT `fk_page_pages_t_core_langs1` FOREIGN KEY (`langs_id`) REFERENCES `core_langs` (`id`),
  CONSTRAINT `fk_page_pages_t_page_pages1` FOREIGN KEY (`page_id`) REFERENCES `page_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `page_pages_t` (`page_id`, `langs_id`, `name`, `meta_title`, `meta_description`, `meta_keywords`) VALUES
(1,	2,	'Test page',	'Test page',	'Test page',	'Test page'),
(2,	2,	'new one',	'new one',	'new one',	'new one'),
(3,	1,	'Лол',	'Лол',	'Лол',	'Лол');

DROP TABLE IF EXISTS `profile_field`;
CREATE TABLE `profile_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `configuration` text,
  `error_message` varchar(255) DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  `read_only` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProfileField_name_uk` (`name`),
  KEY `ProfileField_type_ix` (`type_id`),
  CONSTRAINT `ProfileField_type_fk` FOREIGN KEY (`type_id`) REFERENCES `profile_field_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `profile_field` (`id`, `name`, `title`, `type_id`, `position`, `required`, `configuration`, `error_message`, `default_value`, `read_only`) VALUES
(1,	'first_name',	'First Name',	2,	1,	0,	NULL,	NULL,	NULL,	0),
(2,	'last_name',	'Last Name',	2,	2,	0,	NULL,	NULL,	NULL,	0),
(3,	'website',	'Website',	2,	3,	0,	NULL,	NULL,	NULL,	0);

DROP TABLE IF EXISTS `profile_field_type`;
CREATE TABLE `profile_field_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProfileFieldType_name_uk` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `profile_field_type` (`id`, `name`, `title`) VALUES
(1,	'integer',	'Integer'),
(2,	'string',	'String'),
(3,	'text',	'Text'),
(4,	'boolean',	'Boolean'),
(5,	'decimal',	'Decimal'),
(6,	'money',	'Money'),
(7,	'date',	'Date only'),
(8,	'datetime',	'Date and Time'),
(9,	'time',	'Time only'),
(10,	'url',	'Url Address'),
(11,	'email',	'Email'),
(12,	'lookup',	'Lookup'),
(13,	'list',	'List');

DROP TABLE IF EXISTS `profile_field_value`;
CREATE TABLE `profile_field_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `Profile_field_ix` (`field_id`),
  KEY `Profile_user_fk` (`user_id`),
  CONSTRAINT `Profile_field_fk` FOREIGN KEY (`field_id`) REFERENCES `profile_field` (`id`),
  CONSTRAINT `Profile_user_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password_hash` varchar(128) NOT NULL,
  `password_reset_token` varchar(32) DEFAULT NULL,
  `auth_key` varchar(128) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '2',
  `last_visit_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delete_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `User_status_ix` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id`, `username`, `email`, `password_hash`, `password_reset_token`, `auth_key`, `status`, `last_visit_time`, `create_time`, `update_time`, `delete_time`) VALUES
(1,	'Elena',	'elena.zhuga@gmail.com',	'$2y$13$Ub80Viv7dnIfHyo3KRCKjeJhIdTSDJorwqMT8ygciDJ1Q/ISJREQa',	NULL,	'sf8NKhyzaXHfnigwjEFfYPDLAVNcqKhO',	10,	'2014-06-03 22:46:41',	'2014-06-03 22:28:19',	'2014-06-03 22:28:19',	'0000-00-00 00:00:00');

-- 2014-07-28 23:29:50
